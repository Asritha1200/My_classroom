from django.apps import AppConfig


class MyClassroomAppConfig(AppConfig):
    name = 'my_classroom_app'
